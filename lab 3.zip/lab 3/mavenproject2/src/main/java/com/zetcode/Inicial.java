package com.zetcode;

import javax.swing.*;
import java.awt.*;

class PointsE extends JFrame {
    public PointsE() {
        initUI();
    }

    private void initUI() {
        final com.zetcode.Surface surface = new com.zetcode.Surface();
        add(surface);
        setSize(650, 350);
        setMinimumSize(new Dimension(350,650));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            PointsE ex = new PointsE();
            ex.setVisible(true);
        });
    }
}
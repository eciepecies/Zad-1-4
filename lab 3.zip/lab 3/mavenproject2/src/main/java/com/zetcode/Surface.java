package com.zetcode;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

class Surface extends JPanel {
    public Surface() { }

    void beziere(int[][] x, int[][] y, Graphics2D g2d){
        double t;
        BasicStroke bs1 = new BasicStroke(6, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
        g2d.setStroke(bs1);
        g2d.setColor(Color.blue);
        for(int a=1;a<x.length;a++){
            for(t=0.0;t<1.0;t+=0.01){
                double xt= Math.pow(1-t,3)*x[a-1][2] + 3*t*Math.pow(1-t,2)*x[a][0] + 3*Math.pow(t,2)*(1-t)*x[a][1] + Math.pow(t,3)*x[a][2];
                double yt= Math.pow(1-t,3)*y[a-1][2] + 3*t*Math.pow(1-t,2)*y[a][0] + 3*Math.pow(t,2)*(1-t)*y[a][1] + Math.pow(t,3)*y[a][2];

                g2d.drawLine((int)xt,(int)yt,(int)xt,(int)yt);
            }
        }
        BasicStroke bs2 = new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
        g2d.setStroke(bs2);
        for(int b=0;b<x.length;b++){
            for(int a=0;a<3;a++){
                int xt= x[b][a];
                int yt= y[b][a];

                g2d.setColor(Color.white);
                g2d.drawLine(xt,yt,xt,yt);
            }
        }

    }

    void beziere_line(int[] x, int[] y, Graphics2D g2d){
        double t;
        g2d.setColor(Color.blue);
        for(t=0.0;t<1.0;t+=0.01){
            double xt= Math.pow(1-t,3)*x[0] + 3*t*Math.pow(1-t,2)*x[1] + 3*Math.pow(t,2)*(1-t)*x[2] + Math.pow(t,3)*x[3];
            double yt= Math.pow(1-t,3)*y[0] + 3*t*Math.pow(1-t,2)*y[1] + 3*Math.pow(t,2)*(1-t)*y[2] + Math.pow(t,3)*y[3];

            g2d.drawLine((int)xt,(int)yt,(int)xt,(int)yt);
        }
        BasicStroke bs2 = new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL);
        g2d.setStroke(bs2);
        g2d.setColor(Color.white);
        for(int a=0;a<3;a++){
            int xt= x[a];
            int yt= y[a];
            g2d.drawLine(xt,yt,xt,yt);
        }
    }

    private void doDrawing(Graphics g) {
         this.setBackground(Color.red);
        Graphics2D g2d = (Graphics2D) g.create();

        int xoff=95; 
        int yoff=444; 
        
        
        int[][] x = new int[][]{ // podaje wartosci x  
            
        {80 + xoff, 20+ xoff,20 + xoff},   
        {92 + xoff, 146+ xoff,141 + xoff},
        {136 + xoff,217 + xoff,212 + xoff},
        {207 + xoff,276 + xoff,275 + xoff},
        {277 + xoff,306 + xoff,291 + xoff},
        {276 + xoff,455 + xoff,455 + xoff},
        {455 + xoff, 469 + xoff,454 + xoff},
        {439 + xoff,369 + xoff,354 + xoff},
        {339 + xoff,564 + xoff,549 + xoff}};
                

        
        int[][] y = new int[][]{ // podaje wartosci y
        
    //   {442 + yoff, 39 + xoff, 440 + yoff, 38 + xoff, 455 + yoff},
        {480 + yoff,450 + yoff,460 + yoff},
        {459 + yoff,193 + yoff,179 + yoff},
        {165 + yoff,352 + yoff,336 + yoff},
        {380 + yoff,203 + yoff,188 + yoff},
        {173 + yoff,426 + yoff,426 + yoff},
        {426 + yoff,415 + yoff,430 + yoff},
        {445 + yoff,180 + yoff,180 + yoff},
        {180 + yoff,177 + yoff,177 + yoff},
        {177 + yoff,181 + yoff,181 + yoff}};

        beziere(x,y, g2d);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }
}
